import request from '../utils/request.js'
import { API_BASE } from '../config/api.js'

// 管理员登录
export const adminLogin = (username, password) => {
  return request.post(`${API_BASE.adminSys}/adminLogin`, {
    username,
    password
  })
}

// 获取员工列表
export const getStaffList = (token) => {
  return request.post(`${API_BASE.adminSys}/manageStaff`, {
    token,
    action: 'list'
  })
}

// 添加员工
export const addStaff = (token, staff) => {
  return request.post(`${API_BASE.adminSys}/manageStaff`, {
    token,
    action: 'add',
    staff
  })
}

// 编辑员工
export const editStaff = (token, staff) => {
  return request.post(`${API_BASE.adminSys}/manageStaff`, {
    token,
    action: 'edit',
    staff
  })
}

// 禁用/启用员工
export const disableStaff = (token, staffId, disabled) => {
  return request.post(`${API_BASE.adminSys}/manageStaff`, {
    token,
    action: 'disable',
    staff: { _id: staffId, disabled }
  })
}
