<template>
  <div class="glass-card">
    <div class="filter-container" style="display:flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
      <div style="display:flex; gap:12px; flex-wrap: wrap;">
        <el-input v-model="wo.search" placeholder="搜索姓名/手机号/设备号" style="width: 240px;" clearable prefix-icon="Search"></el-input>
        <el-select v-model="wo.filter" placeholder="工单状态" clearable style="width: 130px;">
          <el-option label="待处理" value="待处理"></el-option>
          <el-option label="维修中" value="维修中"></el-option>
          <el-option label="已发货" value="已发货"></el-option>
        </el-select>
      </div>
      <el-button type="primary" class="top-btn-text" @click="exportToExcel"><el-icon><Download /></el-icon> 导出</el-button>
    </div>

    <div class="table-responsive">
      <el-table :data="pagedOrders" class="modern-table" style="width: 100%">
        <el-table-column prop="id" label="工单编号" width="150" show-overflow-tooltip></el-table-column>

        <el-table-column label="报修方信息" width="180">
          <template #default="{row}">
            <div style="font-weight:600;color:#1d2129;font-size:13px;">{{ row.clinicName }}</div>
            <div style="color:#4e5969;font-size:12px;">{{ row.customerName }}</div>
            <div style="color:#86909c;font-size:12px;">{{ row.phone }}</div>
          </template>
        </el-table-column>

        <el-table-column label="设备与故障" width="200">
          <template #default="{row}">
            <div style="font-weight:600;color:var(--el-color-primary);font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">{{ row.productModel }}</div>
            <div style="font-size:11px;color:#86909c;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;">{{ row.fault }}</div>
          </template>
        </el-table-column>

        <el-table-column label="物流信息" width="220">
          <template #default="{row}">
            <div style="font-size:12px;color:#4e5969;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
              <span style="color:#86909c;">寄出：</span>{{ row.senderAddress }}
            </div>
            <div style="font-size:12px;color:#4e5969;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
              <span style="color:#86909c;">回寄：</span>{{ row.returnAddress }}
            </div>
          </template>
        </el-table-column>

        <el-table-column label="处理状态" width="130">
          <template #default="{row}">
            <el-tag :type="row.status==='已发货'?'success':row.status==='维修中'?'primary':'warning'" effect="light" round size="small">{{ row.status }}</el-tag>
            <div style="font-size:11px;color:#86909c;margin-top:4px;">{{ row.isHandled ? '已处理' : '待处理' }}</div>
          </template>
        </el-table-column>

        <el-table-column label="发票状态" width="110">
          <template #default="{row}">
            <el-tag v-if="row.invoiceStatus" :type="row.invoiceStatus==='已开具'?'success':row.invoiceStatus==='开具中'?'primary':'info'" effect="light" round size="small">{{ row.invoiceStatus }}</el-tag>
            <span v-else style="color:#86909c;font-size:12px;">无需开票</span>
          </template>
        </el-table-column>

        <el-table-column label="操作" width="80" fixed="right" align="right">
          <template #default="{row}">
            <el-button type="primary" link @click="openDrawer(row)">处理</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <div style="display:flex;justify-content:flex-end;margin-top:20px; overflow-x: auto;">
      <el-pagination v-model:current-page="wo.page" v-model:page-size="wo.pageSize" :total="filteredOrders.length" layout="prev, pager, next" background></el-pagination>
    </div>
  </div>

  <el-drawer v-model="drawerVisible" title="报修工单处理" direction="rtl" :size="isMobile ? '100%' : '500px'">
    <template v-if="currentOrder">
      <div style="padding: 0 10px; color:#4e5969; font-size:14px; line-height:2;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 16px;">
          <span style="font-size:16px; font-weight:600; color:#1d2129;">{{currentOrder.id}}</span>
          <el-tag :type="currentOrder.status==='已发货'?'success':currentOrder.status==='维修中'?'primary':'warning'">{{currentOrder.status}}</el-tag>
        </div>
        <div style="background:#f7f8fa; padding:16px; border-radius:8px; margin-bottom:20px;">
          <p style="font-weight:600;color:#1d2129;margin:0 0 8px;">寄出信息</p>
          <p style="margin:0;">物流公司：{{currentOrder.logisticsCompany}}</p>
          <p style="margin:0;">物流单号：{{currentOrder.logisticsNo}}</p>
        </div>
        <div style="background:#f7f8fa; padding:16px; border-radius:8px; margin-bottom:20px;">
          <p style="font-weight:600;color:#1d2129;margin:0 0 8px;">回寄信息</p>
          <p style="margin:0;">诊所名称：{{currentOrder.clinicName}}</p>
          <p style="margin:0;">收件人姓名：{{currentOrder.customerName}}</p>
          <p style="margin:0;">手机号码：{{currentOrder.phone}}</p>
          <p style="margin:0;">详细地址：{{currentOrder.address}}</p>
          <p style="margin:0;">回寄物流：{{currentOrder.returnCompany || '暂无（待发货）'}}</p>
          <p style="margin:0;">回寄单号：{{currentOrder.returnNo || '暂无（待发货）'}}</p>
        </div>
        <div style="background:#f7f8fa; padding:16px; border-radius:8px; margin-bottom:20px;">
          <p style="font-weight:600;color:#1d2129;margin:0 0 8px;">产品信息</p>
          <p style="margin:0;">产品型号：{{currentOrder.productModel}}</p>
          <p style="margin:0;">物品清单：{{currentOrder.itemsList}}</p>
        </div>
        <div style="background:#f7f8fa; padding:16px; border-radius:8px; margin-bottom:20px;">
          <p style="font-weight:600;color:#1d2129;margin:0 0 8px;">故障信息</p>
          <p style="margin:0;">故障描述：{{currentOrder.fault}}</p>
          <p style="margin:8px 0 6px;color:#86909c;">故障照片/视频：</p>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <el-image v-for="(img, index) in currentOrder.images" :key="index" :src="img" :preview-src-list="currentOrder.images" style="width:72px;height:72px;border-radius:8px;" fit="cover"></el-image>
          </div>
        </div>
        <div style="background:#f7f8fa; padding:16px; border-radius:8px; margin-bottom:20px;">
          <p style="font-weight:600;color:#1d2129;margin:0 0 8px;">财务/发票信息</p>
          <p style="margin:0;">是否需要开票：{{currentOrder.needInvoice ? '是' : '否'}}</p>
          <template v-if="currentOrder.needInvoice">
            <p style="margin:0;">发票抬头：{{currentOrder.invoiceTitle}}</p>
            <p style="margin:0;">税号：{{currentOrder.taxId}}</p>
            <p style="margin:0;">开票状态：<el-tag :type="currentOrder.invoiceStatus === '已开具' ? 'success' : 'warning'" size="small">{{currentOrder.invoiceStatus}}</el-tag></p>
          </template>
        </div>
        <div style="background:#f7f8fa; padding:16px; border-radius:8px; margin-bottom:20px;">
          <p style="font-weight:600;color:#1d2129;margin:0 0 8px;">工单信息</p>
          <p style="margin:0;">工单编号：{{currentOrder.id}}</p>
          <p style="margin:0;">提交时间：{{currentOrder.submitTime}}</p>
          <p style="margin:0;">当前状态：<el-tag :type="currentOrder.status==='已发货'?'success':currentOrder.status==='维修中'?'primary':'warning'" size="small">{{currentOrder.status}}</el-tag></p>
        </div>
        <el-divider border-style="dashed"></el-divider>
        <p style="font-weight:600;color:#1d2129;margin:0 0 8px;">更改工单进度</p>
        <el-radio-group v-model="newStatus">
          <el-radio label="待处理">待处理</el-radio>
          <el-radio label="维修中">维修中</el-radio>
          <el-radio label="已发货">已发货</el-radio>
        </el-radio-group>
      </div>
    </template>
    <template #footer>
      <div style="display:flex; justify-content:space-between; width:100%;">
        <el-button @click="printOrder" plain><el-icon><Printer /></el-icon> 打印</el-button>
        <div>
          <el-button @click="drawerVisible=false">关闭</el-button>
          <el-button type="primary" @click="confirmStatus">保存</el-button>
        </div>
      </div>
    </template>
  </el-drawer>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import * as XLSX from 'xlsx'

const route = useRoute()
const isMobile = ref(window.innerWidth <= 768)

const orders = reactive([
  {
    id: 'WO-2026-0001', clinicName: '阳光口腔诊所', customerName: '刘晓华', phone: '138****5678',
    address: '上海市浦东新区张江高科技园区博云路2号',
    senderAddress: '上海市浦东新区张江高科技园区博云路2号',
    returnAddress: '上海市浦东新区张江高科技园区博云路2号',
    productModel: '全景X光机 Planmeca ProMax', itemsList: '主机×1、传感器×1、电源线×1',
    fault: '开机后图像传感器无响应，屏幕显示连接错误代码E-04',
    status: '待处理', isHandled: false, submitTime: '2026-05-01 09:12',
    logisticsCompany: '顺丰速运', logisticsNo: 'SF1234567890', returnCompany: '', returnNo: '',
    needInvoice: true, invoiceTitle: '瑞尔齿科医疗有限公司', taxId: '91440000123456789W', invoiceStatus: '开具中',
    images: ['https://dummyimage.com/100x100/e0e0e0/909399.png&text=Photo', 'https://dummyimage.com/100x100/e0e0e0/909399.png&text=Photo']
  },
  {
    id: 'WO-2026-0002', clinicName: '康美齿科中心', customerName: '陈美玲', phone: '139****2341',
    address: '北京市朝阳区建国路88号SOHO现代城A座',
    senderAddress: '北京市朝阳区建国路88号SOHO现代城A座',
    returnAddress: '北京市朝阳区建国路88号SOHO现代城A座',
    productModel: '牙椅综合治疗台 A-dec 500', itemsList: '治疗台×1、脚踏控制器×1',
    fault: '治疗台水路出现漏水，脚踏控制器偶发失灵',
    status: '维修中', isHandled: true, submitTime: '2026-05-05 14:30',
    logisticsCompany: '京东物流', logisticsNo: 'JD9876543210', returnCompany: '顺丰速运', returnNo: 'SF9876543210',
    needInvoice: false, invoiceTitle: '', taxId: '', invoiceStatus: '',
    images: ['https://dummyimage.com/100x100/e0e0e0/909399.png&text=Photo', 'https://dummyimage.com/100x100/e0e0e0/909399.png&text=Photo']
  },
  {
    id: 'WO-2026-0003', clinicName: '微笑牙科诊所', customerName: '王建国', phone: '137****9012',
    address: '广州市天河区珠江新城花城大道68号',
    senderAddress: '广州市天河区珠江新城花城大道68号',
    returnAddress: '广州市天河区珠江新城花城大道68号',
    productModel: '口腔CBCT NewTom 5G', itemsList: '主机×1、旋转臂×1',
    fault: '扫描时旋转臂异响，重建图像出现伪影',
    status: '已发货', isHandled: true, submitTime: '2026-05-08 10:05',
    logisticsCompany: '圆通速递', logisticsNo: 'YT5566778899', returnCompany: '圆通速递', returnNo: 'YT1122334455',
    needInvoice: true, invoiceTitle: '广州微笑医疗管理有限公司', taxId: '91440100MA9XXXXXX', invoiceStatus: '已开具',
    images: ['https://dummyimage.com/100x100/e0e0e0/909399.png&text=Photo']
  },
])

const wo = reactive({ search: '', filter: '', page: 1, pageSize: 10 })

const filteredOrders = computed(() =>
  orders.filter(o =>
    (!wo.filter || o.status === wo.filter) &&
    (!wo.search || o.customerName.includes(wo.search) || o.phone.includes(wo.search) || o.productModel.includes(wo.search))
  )
)

const pagedOrders = computed(() => {
  const start = (wo.page - 1) * wo.pageSize
  return filteredOrders.value.slice(start, start + wo.pageSize)
})

onMounted(() => {
  if (route.query.filter) wo.filter = route.query.filter
})

const drawerVisible = ref(false)
const currentOrder = ref(null)
const newStatus = ref('')

const openDrawer = (row) => { currentOrder.value = row; newStatus.value = row.status; drawerVisible.value = true }
const confirmStatus = () => { currentOrder.value.status = newStatus.value; currentOrder.value.isHandled = newStatus.value !== '待处理'; drawerVisible.value = false; ElMessage.success('工单进度更新成功') }
const printOrder = () => { ElMessage.info('触发调用浏览器/本地打印机API') }

const exportToExcel = () => {
  const dataToExport = filteredOrders.value.map(order => ({
    '工单编号': order.id,
    '提交时间': order.submitTime,
    '当前状态': order.status,
    '诊所名称': order.clinicName,
    '客户姓名': order.customerName,
    '联系电话': order.phone,
    '详细地址(回寄/寄出)': order.address,
    '产品型号': order.productModel,
    '物品清单': order.itemsList,
    '故障描述': order.fault,
    '照片/视频附件': order.images ? order.images.join(' \n ') : '无附件',
    '寄出物流公司': order.logisticsCompany,
    '寄出物流单号': order.logisticsNo,
    '回寄物流公司': order.returnCompany || '暂无',
    '回寄物流单号': order.returnNo || '暂无',
    '需开具发票': order.needInvoice ? '是' : '否',
    '发票抬头': order.invoiceTitle || '-',
    '企业税号': order.taxId || '-',
    '发票状态': order.invoiceStatus || '-',
  }))
  const worksheet = XLSX.utils.json_to_sheet(dataToExport)
  worksheet['!cols'] = [
    { wch: 16 }, { wch: 18 }, { wch: 10 }, { wch: 20 }, { wch: 10 },
    { wch: 15 }, { wch: 30 }, { wch: 20 }, { wch: 20 }, { wch: 30 },
    { wch: 50 }, { wch: 15 }, { wch: 20 }, { wch: 15 }, { wch: 20 },
    { wch: 12 }, { wch: 25 }, { wch: 25 }, { wch: 10 },
  ]
  const workbook = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(workbook, worksheet, '工单明细')
  XLSX.writeFile(workbook, `报修工单导出数据_${new Date().toISOString().slice(0, 10)}.xlsx`)
}
</script>

<style scoped>
.glass-card { background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 2px 12px rgba(0,0,0,0.03); margin-bottom: 20px; }
.table-responsive { width: 100%; overflow-x: auto; }
.modern-table { min-width: 900px; }
.modern-table :deep(.el-table__inner-wrapper::before) { display: none; }
.modern-table :deep(th.el-table__cell) { background-color: #f7f8fa !important; color: #4e5969; font-weight: 600; border-bottom: none; }
.modern-table :deep(td.el-table__cell) { border-bottom: 1px solid #f0f2f5; padding: 12px 0; }

@media screen and (max-width: 768px) {
  .filter-container { flex-direction: column; align-items: stretch !important; gap: 12px; }
  .filter-container .el-input, .filter-container .el-select { width: 100% !important; }
}
</style>
